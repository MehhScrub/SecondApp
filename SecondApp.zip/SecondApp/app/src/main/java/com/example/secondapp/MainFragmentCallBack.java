package com.example.secondapp;

/**
 * Created by Zygimantas on 2016.10.19.
 */

public interface MainFragmentCallBack {
    void goNextFragment(int currFragmentId, String params);
}
