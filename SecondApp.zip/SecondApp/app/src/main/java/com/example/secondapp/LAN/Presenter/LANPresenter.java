package com.example.secondapp.LAN.Presenter;

import com.example.secondapp.LAN.Views.LANView;

import java.util.ArrayList;
import java.util.List;

public class LANPresenter {
    private LANView view;

    public LANPresenter(LANView view) {
        this.view = view;
    }

    public void viewCreated(){
        List<String> Listas = new ArrayList<>();

        for(int i = 0; i<=20;i++){
            Listas.add(String.valueOf(i)+" "+ "Studentas");
        }

        String val = Listas.get(5);
    }

}
