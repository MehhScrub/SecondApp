package com.example.secondapp.LAN.Views;

public interface LANView {
}
