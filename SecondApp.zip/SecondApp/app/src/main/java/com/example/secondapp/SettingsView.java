package com.example.secondapp;



public interface SettingsView {
}
