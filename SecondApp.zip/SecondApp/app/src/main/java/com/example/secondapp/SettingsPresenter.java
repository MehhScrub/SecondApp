package com.example.secondapp;


/**
 * Created by ZYGIMANTAS on 2017-09-07.
 */

public class SettingsPresenter /*implements ILanguagePresenter*/ {
    private final SettingsView view;

    public SettingsPresenter(SettingsView view) {
        this.view = view;
    }

    public void viewCreated () {

    }
}
