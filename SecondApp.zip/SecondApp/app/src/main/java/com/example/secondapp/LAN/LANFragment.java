package com.example.secondapp.LAN;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.secondapp.LAN.Presenter.LANPresenter;
import com.example.secondapp.LAN.Views.LANView;
import com.example.secondapp.R;


public class LANFragment extends Fragment implements LANView {
    private LANPresenter presenter;



    public static LANFragment newInstance(Bundle args) {
        LANFragment f = new LANFragment();
        //args.putInt(PANEL_TYPE, tipas);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        presenter = new LANPresenter(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.lan_main, container, false);
//        ButterKnife.bind(this, rootView);
        presenter.viewCreated();

        return rootView;
    }

}
